
extends RefCounted
class_name PlayerMovementController


# ==================================================
# 枚举
# ==================================================

enum MovementEndReason {
	COMPLETED,
	CANCELLED,
	REPLACED,
	JUMP_INTERRUPTED
}

enum MovementMode {
	NONE,
	DASH,
	VELOCITY_OVERRIDE
}

enum PhaseMode {
	SPEED_PROTECTION,
	LINEAR_INTERPOLATION,
	DIRECT_SET
}

enum EndVelocityMode {
	PRESERVE_CURRENT,
	SET_SPEED
}


# ==================================================
# 基础移动
# ==================================================

var move_speed: float = 360.0
var ground_acceleration: float = 4000.0
var ground_deceleration: float = 4000.0
var ground_overspeed_deceleration: float = 1600.0
var air_acceleration_multiplier: float = 0.65


# ==================================================
# 跳跃
# ==================================================

var jump_velocity: float = -1000.0
var gravity: float = 3000.0
var jump_cut_multiplier: float = 0.45


# ==================================================
# 蹲伏
# ==================================================

var crouch_friction: float = 2000.0


# ==================================================
# 狼跳与跳跃缓存
# ==================================================

var coyote_time: float = 0.8
var coyote_timer: float = 0.0

var jump_buffer_time: float = 2.0
var jump_buffer_timer: float = 0.0


# ==================================================
# Dash 配置
# ==================================================

var dash_action_data: CombatActionData

var dash_max_charges: int = 2
var dash_recharge_time: float = 1.20

var dash_charges: int = 2
var dash_recharge_timers: Array[float] = []

var dash_buffered: bool = false
var dash_buffered_direction: Vector2 = Vector2.ZERO



# ==================================================
# Movement 独立运行状态
# ==================================================

var active_movement_source_id: StringName = &""
var active_movement_request: Dictionary = {}

var movement_action_detached: bool = false
var movement_end_velocity_settled: bool = false


# ==================================================
# Movement 运行计时与阶段状态
# ==================================================

var movement_phase_elapsed: float = 0.0
var movement_finished: bool = false
var movement_suppress_gravity: bool = false

var movement_phase_start_velocity: Vector2 = Vector2.ZERO
var movement_phase_initialized: bool = false

var movement_vertical_released: bool = false
var movement_airborne_time: float = 0.0


# ==================================================
# 外部引用
# ==================================================

var action_executor: CombatActionExecutor
var actor: Node2D
var defense_controller: DefenseController


func _init(
	p_action_executor: CombatActionExecutor,
	p_actor: Node2D
) -> void:
	action_executor = p_action_executor
	actor = p_actor

	if actor != null:
		defense_controller = actor.get_node_or_null(
			"DefenseController"
		) as DefenseController


# ==================================================
# 普通水平移动
# ==================================================

func update_movement(
	actor_delta: float,
	current_velocity: Vector2,
	move_input: Vector2,
	actor_is_on_floor: bool,
	is_crouching: bool = false
) -> Vector2:

	if actor_is_on_floor and is_crouching:
		current_velocity.x = move_toward(
			current_velocity.x,
			0.0,
			crouch_friction * actor_delta
		)
		return current_velocity

	var target_speed: float = move_input.x * move_speed
	var acceleration: float = 0.0

	var air_multiplier: float = 1.0

	if not actor_is_on_floor:
		air_multiplier = air_acceleration_multiplier

	if is_zero_approx(move_input.x):
		acceleration = ground_deceleration * air_multiplier

	elif current_velocity.x * move_input.x < 0.0:
		acceleration = ground_acceleration * air_multiplier

	elif absf(current_velocity.x) > move_speed:
		acceleration = ground_overspeed_deceleration * air_multiplier

	else:
		acceleration = ground_acceleration * air_multiplier

	current_velocity.x = move_toward(
		current_velocity.x,
		target_speed,
		acceleration * actor_delta
	)

	return current_velocity


# ==================================================
# 重力
# ==================================================

func apply_gravity(
	actor_delta: float,
	current_velocity: Vector2,
	actor_is_on_floor: bool,
	suppress_gravity: bool
) -> Vector2:

	if not actor_is_on_floor and not suppress_gravity:
		current_velocity.y += gravity * actor_delta

	return current_velocity


# ==================================================
# 跳跃
# ==================================================

func apply_jump(current_velocity: Vector2) -> Vector2:

	# 跳跃成功启动时，中断当前 Action Movement。
	# 跳跃中断不执行旧 Movement 的 End Velocity。
	if has_action_movement():
		_finish_active_movement(
			MovementEndReason.JUMP_INTERRUPTED
		)

	current_velocity.y = jump_velocity
	return current_velocity


func cut_jump(current_velocity: Vector2) -> Vector2:

	if current_velocity.y < 0.0:
		current_velocity.y *= jump_cut_multiplier

	return current_velocity


# ==================================================
# Movement 状态查询
# ==================================================

func has_action_movement() -> bool:
	return not active_movement_source_id.is_empty()


func get_active_movement_source_id() -> StringName:
	return active_movement_source_id


func get_active_movement_request() -> Dictionary:
	return active_movement_request.duplicate(true)


# ==================================================
# 接收 Action Movement 请求
# ==================================================

func receive_action_movement_request(
	source_id: StringName,
	request: Dictionary
) -> bool:

	# 先验证请求，失败时不影响旧 Movement。
	if source_id.is_empty():
		push_warning("MovementController：Movement 来源 ID 不能为空")
		return false

	if request.is_empty():
		push_warning("MovementController：不能接收空 Movement 请求")
		return false

	var requested_mode: int = int(
		request.get("movement_mode", MovementMode.NONE)
	)

	if (
		requested_mode != MovementMode.DASH
		and requested_mode != MovementMode.VELOCITY_OVERRIDE
	):
		push_warning("MovementController：不支持的 Movement 模式")
		return false

	# 验证方向字段，避免后续运动计算发生类型错误。
	if request.has("dash_direction"):
		if not request["dash_direction"] is Vector2:
			push_warning("MovementController：Dash 方向必须是 Vector2")
			return false

	if request.has("override_direction"):
		if not request["override_direction"] is Vector2:
			push_warning("MovementController：Override 方向必须是 Vector2")
			return false

	# 同一来源重复提交，只更新请求副本。
	if source_id == active_movement_source_id:
		active_movement_request = request.duplicate(true)
		return true

	# 新请求已经验证通过，现在才允许交接旧 Movement。
	if has_action_movement():
		_finish_active_movement(
			MovementEndReason.REPLACED
		)

	# 新来源取得控制权。
	active_movement_source_id = source_id
	active_movement_request = request.duplicate(true)

	movement_action_detached = false
	movement_end_velocity_settled = false

	_reset_movement_runtime_state()

	return true


# ==================================================
# Action 生命周期通知
# ==================================================

func notify_movement_action_finished(
	source_id: StringName,
	end_reason: MovementEndReason
) -> void:

	# 旧来源不能清理新来源。
	if source_id != active_movement_source_id:
		return

	match end_reason:

		MovementEndReason.COMPLETED:
			# Action 已结束，但 Movement 继续独立运行。
			movement_action_detached = true

		MovementEndReason.CANCELLED:
			_finish_active_movement(
				MovementEndReason.CANCELLED
			)

		MovementEndReason.REPLACED:
			_finish_active_movement(
				MovementEndReason.REPLACED
			)

		MovementEndReason.JUMP_INTERRUPTED:
			_finish_active_movement(
				MovementEndReason.JUMP_INTERRUPTED
			)


# ==================================================
# Movement 自身结束
# ==================================================

func finish_action_movement(
	source_id: StringName
) -> void:

	if source_id != active_movement_source_id:
		return

	_finish_active_movement(
		MovementEndReason.COMPLETED
	)


# ==================================================
# Movement 结束处理
# ==================================================

func _finish_active_movement(
	end_reason: MovementEndReason
) -> void:

	if not has_action_movement():
		return

	# 正常完成和被替换时执行 End Velocity。
	# 取消和跳跃中断保留当前速度。
	if (
		end_reason == MovementEndReason.COMPLETED
		or end_reason == MovementEndReason.REPLACED
	):
		_apply_movement_end_velocity_once()

	_clear_active_movement()


func _clear_active_movement() -> void:

	active_movement_source_id = &""
	active_movement_request.clear()

	movement_action_detached = false
	movement_end_velocity_settled = false

	_reset_movement_runtime_state()


# ==================================================
# End Velocity 一次性结算
# ==================================================

func _apply_movement_end_velocity_once() -> void:

	if movement_end_velocity_settled:
		return

	if actor == null:
		movement_end_velocity_settled = true
		return

	var current_velocity: Vector2 = actor.get("velocity")

	current_velocity = _calculate_movement_end_velocity(
		current_velocity,
		active_movement_request
	)

	actor.set("velocity", current_velocity)

	movement_end_velocity_settled = true


func _calculate_movement_end_velocity(
	current_velocity: Vector2,
	request: Dictionary
) -> Vector2:

	var movement_mode: int = int(
		request.get("movement_mode", MovementMode.NONE)
	)

	match movement_mode:

		MovementMode.DASH:
			return _calculate_dash_end_velocity(
				current_velocity,
				request
			)

		MovementMode.VELOCITY_OVERRIDE:
			return _calculate_override_end_velocity(
				current_velocity,
				request
			)

	return current_velocity


func _calculate_dash_end_velocity(
	current_velocity: Vector2,
	request: Dictionary
) -> Vector2:

	if not bool(request.get("end_velocity_enabled", true)):
		return current_velocity

	var direction: Vector2 = request.get(
		"dash_direction",
		Vector2.RIGHT
	)

	if direction.length_squared() <= 0.0001:
		return current_velocity

	direction = direction.normalized()

	var exclude_diagonal_down: bool = bool(
		request.get("exclude_diagonal_down_end", true)
	)

	var is_diagonal_down: bool = (
		direction.x != 0.0
		and direction.y > 0.0
	)

	if exclude_diagonal_down and is_diagonal_down:
		return current_velocity

	var end_speed: float = maxf(
		float(request.get("end_speed", 160.0)),
		0.0
	)

	var end_velocity: Vector2 = direction * end_speed

	if direction.x == 0.0 and direction.y < 0.0:
		var multiplier: float = float(
			request.get("dash_up_end_y_multiplier", 0.75)
		)

		end_velocity.y *= multiplier

	elif direction.x != 0.0 and direction.y < 0.0:
		var multiplier: float = float(
			request.get(
				"dash_diagonal_up_end_y_multiplier",
				0.75
			)
		)

		end_velocity.y *= multiplier

	return end_velocity


func _calculate_override_end_velocity(
	current_velocity: Vector2,
	request: Dictionary
) -> Vector2:

	var end_velocity_mode: int = int(
		request.get(
			"end_velocity_mode",
			EndVelocityMode.PRESERVE_CURRENT
		)
	)

	if end_velocity_mode != EndVelocityMode.SET_SPEED:
		return current_velocity

	var end_speed: float = maxf(
		float(request.get("end_speed", 0.0)),
		0.0
	)

	var direction: Vector2 = request.get(
		"override_direction",
		Vector2.RIGHT
	)

	if direction.length_squared() <= 0.0001:
		return current_velocity

	return direction.normalized() * end_speed


# ==================================================
# 更新 Action Movement
# ==================================================

func update_action_movement(
	actor_delta: float,
	current_velocity: Vector2,
	actor_gravity: float,
	actor_is_on_floor: bool
) -> Dictionary:

	var result := {
		"active": false,
		"velocity": current_velocity,
		"suppress_gravity": false
	}

	if not has_action_movement():
		return result

	if movement_finished:
		return result

	var movement_mode: int = int(
		active_movement_request.get(
			"movement_mode",
			MovementMode.NONE
		)
	)

	match movement_mode:

		MovementMode.DASH:
			return _update_dash_movement(
				actor_delta,
				current_velocity
			)

		MovementMode.VELOCITY_OVERRIDE:
			return _update_velocity_override(
				actor_delta,
				current_velocity,
				actor_gravity,
				actor_is_on_floor
			)

		_:
			return result


# ==================================================
# DASH 实际运动
# ==================================================

func _update_dash_movement(
	actor_delta: float,
	current_velocity: Vector2
) -> Dictionary:

	var result := {
		"active": true,
		"velocity": current_velocity,
		"suppress_gravity": true
	}

	var direction: Vector2 = active_movement_request.get(
		"dash_direction",
		_get_facing_direction()
	)

	if direction.length_squared() <= 0.0001:
		direction = _get_facing_direction()

	direction = direction.normalized()

	var dash_speed: float = maxf(
		float(active_movement_request.get("dash_speed", 0.0)),
		0.0
	)

	var dash_duration: float = maxf(
		float(active_movement_request.get("dash_duration", 0.01)),
		0.01
	)

	var target_velocity: Vector2 = direction * dash_speed

	# 同方向时保留较大的原有水平速度。
	if direction.x != 0.0:
		if current_velocity.x * direction.x > 0.0:
			if absf(current_velocity.x) > absf(target_velocity.x):
				target_velocity.x = current_velocity.x

	# 纯垂直 Dash 不继承原有水平速度。
	else:
		target_velocity.x = 0.0

	movement_phase_elapsed += actor_delta

	if movement_phase_elapsed >= dash_duration:
		movement_phase_elapsed = dash_duration

		# 使用本帧计算出的速度结算 End Velocity。
		target_velocity = _complete_movement_with_velocity(
			target_velocity
		)

	result["velocity"] = target_velocity

	return result


# ==================================================
# Velocity Override 实际运动
# ==================================================

func _update_velocity_override(
	actor_delta: float,
	current_velocity: Vector2,
	actor_gravity: float,
	actor_is_on_floor: bool
) -> Dictionary:

	var result := {
		"active": true,
		"velocity": current_velocity,
		"suppress_gravity": false
	}

	var direction: Vector2 = active_movement_request.get(
		"override_direction",
		_get_facing_direction()
	)

	if direction.length_squared() <= 0.0001:
		direction = _get_facing_direction()

	direction = direction.normalized()

	var phase_mode: int = int(
		active_movement_request.get(
			"override_phase_mode",
			PhaseMode.SPEED_PROTECTION
		)
	)

	var phase_speed: float = maxf(
		float(active_movement_request.get("override_speed", 0.0)),
		0.0
	)

	var phase_duration: float = maxf(
		float(active_movement_request.get("override_duration", 0.01)),
		0.01
	)

	movement_suppress_gravity = bool(
		active_movement_request.get(
			"override_suppress_gravity",
			false
		)
	)

	# 首次进入阶段时记录初始速度。
	if not movement_phase_initialized:
		movement_phase_start_velocity = current_velocity
		movement_phase_initialized = true

	# 落地后释放垂直方向控制权。
	if actor_is_on_floor:
		movement_vertical_released = true

	# 累计实际处于空中的时间。
	if not actor_is_on_floor and not movement_vertical_released:
		movement_airborne_time += actor_delta

	var target_velocity: Vector2 = direction * phase_speed
	var output_velocity: Vector2 = current_velocity

	match phase_mode:

		PhaseMode.SPEED_PROTECTION:
			output_velocity = _apply_minimum_velocity_in_direction(
				output_velocity,
				direction,
				phase_speed
			)

		PhaseMode.LINEAR_INTERPOLATION:
			var next_elapsed: float = minf(
				movement_phase_elapsed + actor_delta,
				phase_duration
			)

			var progress: float = clampf(
				next_elapsed / phase_duration,
				0.0,
				1.0
			)

			var interpolated_velocity: Vector2 = (
				movement_phase_start_velocity.lerp(
					target_velocity,
					progress
				)
			)

			# 水平方向始终执行线性插值。
			output_velocity.x = interpolated_velocity.x

			# 垂直方向只在尚未释放控制权时执行插值。
			if not movement_vertical_released:
				if not actor_is_on_floor:
					output_velocity.y = interpolated_velocity.y

					# 补回当前阶段累计的重力效果。
					if not movement_suppress_gravity:
						output_velocity.y += (
							actor_gravity * movement_airborne_time
						)

		PhaseMode.DIRECT_SET:
			output_velocity = target_velocity

		_:
			output_velocity = _apply_minimum_velocity_in_direction(
				output_velocity,
				direction,
				phase_speed
			)

	movement_phase_elapsed += actor_delta

	if movement_phase_elapsed >= phase_duration:
		movement_phase_elapsed = phase_duration

		output_velocity = _complete_movement_with_velocity(
			output_velocity
		)

	result["velocity"] = output_velocity
	result["suppress_gravity"] = movement_suppress_gravity

	return result


# ==================================================
# Movement 完成与本帧速度结算
# ==================================================

func _complete_movement_with_velocity(
	current_velocity: Vector2
) -> Vector2:

	if not has_action_movement():
		return current_velocity

	if movement_end_velocity_settled:
		return current_velocity

	current_velocity = _calculate_movement_end_velocity(
		current_velocity,
		active_movement_request
	)

	movement_end_velocity_settled = true

	# 当前速度由 update_action_movement 返回给 Player1。
	# 此处只清理 Movement，不再读取旧的 actor.velocity。
	_clear_active_movement()

	return current_velocity


# ==================================================
# 速度保护
# ==================================================

func _apply_minimum_velocity_in_direction(
	current_velocity: Vector2,
	direction: Vector2,
	target_speed: float
) -> Vector2:

	if direction.length_squared() <= 0.0001:
		return current_velocity

	var normalized_direction := direction.normalized()
	var current_speed := current_velocity.dot(normalized_direction)

	if current_speed < target_speed:
		current_velocity += normalized_direction * (
			target_speed - current_speed
		)

	return current_velocity


# ==================================================
# Movement 运行状态重置
# ==================================================

func _reset_movement_runtime_state() -> void:

	movement_phase_elapsed = 0.0
	movement_finished = false
	movement_suppress_gravity = false

	movement_phase_start_velocity = Vector2.ZERO
	movement_phase_initialized = false

	movement_vertical_released = false
	movement_airborne_time = 0.0


# ==================================================
# 动作稳定
# ==================================================

func _get_current_action_movement_request() -> Dictionary:

	if action_executor == null:
		return {}

	if not action_executor.is_action_running():
		return {}

	var context := action_executor.current_context

	if context == null:
		return {}

	var request: Variant = context.runtime_data.get(
		"movement_request",
		{}
	)

	if request is Dictionary:
		return request

	return {}


func has_action_stabilization() -> bool:

	var request := _get_current_action_movement_request()

	var movement_mode: int = int(
		request.get("movement_mode", MovementMode.NONE)
	)

	if movement_mode != MovementMode.NONE:
		return false

	return bool(
		request.get("stabilization_enabled", false)
	)


func apply_action_stabilization(
	current_velocity: Vector2,
	actor_delta: float,
	actor_is_on_floor: bool
) -> Vector2:

	var request := _get_current_action_movement_request()

	var movement_mode: int = int(
		request.get("movement_mode", MovementMode.NONE)
	)

	if movement_mode != MovementMode.NONE:
		return current_velocity

	if not bool(request.get("stabilization_enabled", false)):
		return current_velocity

	var stabilization_speed: float = float(
		request.get("stabilization_speed", 3000.0)
	)

	current_velocity.x = move_toward(
		current_velocity.x,
		0.0,
		stabilization_speed * actor_delta
	)

	var stabilize_vertical: bool = bool(
		request.get("stabilize_vertical_in_air", true)
	)

	if not actor_is_on_floor and stabilize_vertical:
		current_velocity.y = move_toward(
			current_velocity.y,
			0.0,
			stabilization_speed * actor_delta
		)

	return current_velocity


# ==================================================
# Dash 状态查询
# ==================================================

var is_dashing: bool:
	get:
		# Action 尚未结束，或者 Dash Movement 仍在执行，
		# 都视为 Dash 过程尚未完全结束。
		if _get_dash_context() != null:
			return true

		return (
			has_action_movement()
			and int(
				active_movement_request.get(
					"movement_mode",
					MovementMode.NONE
				)
			) == MovementMode.DASH
		)


var is_dash_invincible: bool:
	get:
		if defense_controller == null:
			return false

		return defense_controller.is_invincible


func _get_dash_context() -> CombatActionContext:

	if action_executor == null:
		return null

	var context := action_executor.current_context

	if context == null or not context.is_running:
		return null

	if context.action_data != dash_action_data:
		return null

	return context


func _get_facing_direction() -> Vector2:

	if actor == null:
		return Vector2.RIGHT

	var facing: int = int(actor.get("facing_direction"))

	if facing == 0:
		facing = 1

	return Vector2(facing, 0.0)


# ==================================================
# 请求 Dash
# ==================================================

func request_dash(
	direction: Vector2,
	update_facing: bool = true
) -> bool:

	if dash_charges <= 0:
		return false

	# 第一次 Dash 尚未完全结束时，
	# 将后续输入缓存为第二段 Dash。
	if is_dashing:
		dash_buffered = true
		dash_buffered_direction = _get_dash_direction(direction)
		return true

	return _start_dash(direction, update_facing)

# ==================================================
# 启动 Dash Action
# ==================================================

func _start_dash(
	direction: Vector2,
	update_facing: bool
) -> bool:

	if actor == null or action_executor == null:
		push_warning("Dash 启动失败：缺少角色或 ActionExecutor")
		return false

	if dash_action_data == null:
		push_warning("Dash 启动失败：没有设置 dash_action_data")
		return false

	var dash_direction := _get_dash_direction(direction)

	var current_facing: int = int(
		actor.get("facing_direction")
	)

	if update_facing and not is_zero_approx(dash_direction.x):
		actor.call(
			"_update_facing",
			signf(dash_direction.x)
		)

		current_facing = int(
			actor.get("facing_direction")
		)

	var started: bool = action_executor.start_action(
		dash_action_data,
		actor,
		current_facing,
		dash_direction
	)

	if not started:
		return false

	# 所有方向的 Dash 都清除原有垂直速度。
	var current_velocity: Vector2 = actor.get("velocity")
	current_velocity.y = 0.0
	actor.set("velocity", current_velocity)

	# 只有 Action 成功启动才扣除充能。
	dash_charges -= 1
	dash_recharge_timers.append(dash_recharge_time)

	

	return true


func _get_dash_direction(direction: Vector2) -> Vector2:

	if direction.length_squared() > 0.0001:
		return direction.normalized()

	return _get_facing_direction()


# ==================================================
# Dash 更新
# ==================================================

func update_dash(actor_delta: float) -> void:
	_update_dash_recharge(actor_delta)

	# 没有预输入时，不需要处理。
	if not dash_buffered:
		return

	# 充能不足时，暂时不尝试。
	if dash_charges <= 0:
		return

	# 无敌期间不启动第二段 Dash。
	if is_dash_invincible:
		return

	# 尝试启动第二段 Dash。
	var next_direction := dash_buffered_direction

	var started: bool = _start_dash(
		next_direction,
		true
	)

	# 只有成功启动，才消费预输入。
	if started:
		dash_buffered = false
		dash_buffered_direction = Vector2.ZERO


# ==================================================
# Dash 充能恢复
# ==================================================

func _update_dash_recharge(actor_delta: float) -> void:

	for i in range(dash_recharge_timers.size() - 1, -1, -1):
		dash_recharge_timers[i] -= actor_delta

		if dash_recharge_timers[i] <= 0.0:
			dash_recharge_timers.remove_at(i)

			dash_charges = mini(
				dash_charges + 1,
				dash_max_charges
			)


# ==================================================
# Coyote Time
# ==================================================

func update_coyote_time(
	actor_delta: float,
	actor_is_on_floor: bool
) -> void:

	if actor_is_on_floor:
		coyote_timer = coyote_time
	else:
		coyote_timer = maxf(
			coyote_timer - actor_delta,
			0.0
		)


func can_coyote_jump() -> bool:
	return coyote_timer > 0.0


# ==================================================
# Jump Buffer
# ==================================================

func update_jump_buffer(actor_delta: float) -> void:

	jump_buffer_timer = maxf(
		jump_buffer_timer - actor_delta,
		0.0
	)


func buffer_jump_input() -> void:
	jump_buffer_timer = jump_buffer_time


func has_buffered_jump() -> bool:
	return jump_buffer_timer > 0.0


func consume_buffered_jump() -> void:
	jump_buffer_timer = 0.0
