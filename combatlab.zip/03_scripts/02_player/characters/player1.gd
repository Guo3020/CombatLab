
extends CharacterBody2D


signal debug_damage_number(world_position: Vector2, amount: float)


# ==================================================
# 生命值
# ==================================================

@export_group("生命值")
@export var max_health: float = 100.0

@export_group("受击设置")
@export_range(0, 10, 1)
var default_super_armor_level: int = 0

@export_group("动作资源")
@export var dash_action_data: CombatActionData


func get_effective_super_armor_level() -> int:
	if combat_action_executor.is_action_running():
		return combat_action_executor.current_context.action_data.super_armor_level

	return default_super_armor_level


var current_health: float = 0.0
var is_dead: bool = false





# ==================================================
# Dash 参数
# ==================================================

@export_group("Dash 参数")
@export var dash_max_charges: int = 2
@export var dash_recharge_time: float = 1.20


# ==================================================
# Special Dash 输入参数
# ==================================================

@export_group("Special Dash 输入")
@export_range(0.05, 1.0, 0.05)
var special_dash_hold_threshold: float = 0.10


# Dash 状态统一从对应控制器读取。
var is_dashing: bool:
	get:
		return movement_controller != null and movement_controller.is_dashing


var is_dash_invincible: bool:
	get:
		return movement_controller != null and movement_controller.is_dash_invincible


var is_invincible: bool:
	get:
		return defense_controller != null and defense_controller.is_invincible


var dash_charges: int:
	get:
		if movement_controller == null:
			return 0
		return movement_controller.dash_charges


# ==================================================
# Special Dash 输入状态
# ==================================================

var special_dash_hold_active: bool = false
var special_dash_hold_started_on_floor: bool = false
var special_dash_hold_timer: float = 0.0

var special_dash_press_direction: Vector2 = Vector2.ZERO
var special_dash_last_valid_direction: Vector2 = Vector2.ZERO

var special_dash_preparing: bool = false
var special_dash_ground_attempted: bool = false

# 本次待执行 Dash 是否允许改变角色面向。
var dash_input_updates_facing: bool = true


# ==================================================
# 输入缓存
# ==================================================

var move_input_direction: float = 0.0
var move_input_vector: Vector2 = Vector2.ZERO

var jump_input_pending: bool = false
var jump_button_held: bool = false
var dash_input_pending: bool = false
var dash_input_direction: Vector2 = Vector2.ZERO

var normalattack_input_pending: bool = false
var skill_input_pending: bool = false


# ==================================================
# 角色与战斗系统
# ==================================================

var facing_direction: float = 1.0

var is_hitstop_paused: bool = false

# 运动阶段执行器。
var movement_controller: PlayerMovementController


@onready var combat_action_executor: CombatActionExecutor = $CombatActionExecutor
@onready var combat_combo_executor: CombatComboExecutor = $CombatComboExecutor
@onready var combat_energy: CombatEnergy = $CombatEnergy
@onready var skill_selector: SkillSelector = $SkillSelector
@onready var defense_controller: DefenseController = $DefenseController


# ==================================================
# 调试数据
# ==================================================

var debug_action_name: String = "待机"
var debug_phase_name: String = ""

var debug_startup_duration: float = 0.0
var debug_active_duration: float = 0.0
var debug_recovery_duration: float = 0.0

var debug_action_elapsed: float = 0.0
var debug_action_active: bool = false

var debug_energy_current: float = 0.0
var debug_energy_max: float = 100.0


# ==================================================
# 初始化
# ==================================================

func _ready() -> void:
	current_health = max_health


	movement_controller = PlayerMovementController.new(
		combat_action_executor,
		self
	)

	movement_controller.dash_action_data = dash_action_data
	movement_controller.dash_max_charges = dash_max_charges
	movement_controller.dash_recharge_time = dash_recharge_time
	movement_controller.dash_charges = dash_max_charges

	if current_health <= 0.0:
		die()

	combat_action_executor.action_started.connect(
		_on_executor_action_started
	)

	combat_action_executor.action_phase_changed.connect(
		_on_executor_action_phase_changed
	)

	combat_action_executor.action_finished.connect(
		_on_executor_action_finished
	)

	debug_energy_current = combat_energy.current_energy
	debug_energy_max = combat_energy.MAX_ENERGY

	combat_energy.energy_changed.connect(_on_energy_changed)


# ==================================================
# 输入采集
# ==================================================

func _process(delta: float) -> void:
	if is_dead:
		move_input_direction = 0.0
		move_input_vector = Vector2.ZERO

		jump_input_pending = false
		dash_input_pending = false
		normalattack_input_pending = false
		skill_input_pending = false

		_reset_special_dash_input_state()
		return

	# Debug 时间轴跟随角色时间。
	if debug_action_active:
		var actor_delta: float = CombatTimeManager.get_actor_delta(
			self,
			delta
		)
		debug_action_elapsed += actor_delta

	# 普通移动的水平输入，不进行二维归一化。
	move_input_direction = Input.get_axis(
		"move_left",
		"move_right"
	)

	# 保留独立的二维输入，供 Dash 和特殊动作读取。
	move_input_vector = Vector2(
		move_input_direction,
		Input.get_axis("move_up", "move_down")
	)

	# 普通跳跃输入。
	jump_button_held = Input.is_action_pressed("jump")

	if Input.is_action_just_pressed("jump"):
		jump_input_pending = true
		movement_controller.buffer_jump_input()

	if Input.is_action_just_released("jump"):
		velocity = movement_controller.cut_jump(velocity)

	# Dash 按下。
	if Input.is_action_just_pressed("dodge"):
		_begin_special_dash_input()

	# Dash 按住期间，更新特殊 Dash 方向和计时。
	if special_dash_hold_active and Input.is_action_pressed("dodge"):
		_update_special_dash_hold(delta)

	# Dash 松开。
	if Input.is_action_just_released("dodge"):
		_release_special_dash_input()

	# 普通攻击输入。
	if Input.is_action_just_pressed("normalattack"):
		normalattack_input_pending = true

	# 技能输入。
	if Input.is_action_just_pressed("skill"):
		skill_input_pending = true


# ==================================================
# Special Dash 输入状态机
# ==================================================

func _begin_special_dash_input() -> void:
	special_dash_hold_active = true
	special_dash_hold_started_on_floor = is_on_floor()

	special_dash_hold_timer = 0.0
	special_dash_press_direction = move_input_vector
	special_dash_last_valid_direction = Vector2.ZERO

	special_dash_preparing = false
	special_dash_ground_attempted = false

	# 记录按下瞬间的有效方向。
	if move_input_vector != Vector2.ZERO:
		special_dash_last_valid_direction = move_input_vector.normalized()

	if special_dash_hold_started_on_floor:
		# 地面按下：立即启动普通 Dash。
		# 无方向输入时，使用面向反方向。
		var direction := move_input_vector

		if direction == Vector2.ZERO:
			direction = Vector2(-facing_direction, 0.0)
			dash_input_updates_facing = false
		else:
			dash_input_updates_facing = true

		dash_input_pending = true
		dash_input_direction = direction.normalized()

	else:
		# 空中按下：暂不启动普通 Dash。
		dash_input_updates_facing = true


func _update_special_dash_hold(delta: float) -> void:
	# 持续记录最后一次有效方向。
	if move_input_vector != Vector2.ZERO:
		special_dash_last_valid_direction = move_input_vector.normalized()

	# 顿帧期间不推进长按计时。
	var actor_delta: float = CombatTimeManager.get_actor_delta(
		self,
		delta
	)

	if actor_delta <= 0.0:
		return

	special_dash_hold_timer += actor_delta

	if special_dash_hold_timer < special_dash_hold_threshold:
		return

	# 地面：达到阈值，只尝试一次特殊派生。
	if special_dash_hold_started_on_floor:
		if not special_dash_ground_attempted:
			special_dash_ground_attempted = true
			_try_ground_special_dash()

		return

	# 空中：达到阈值，进入特殊准备状态。
	if not special_dash_preparing:
		special_dash_preparing = true


func _release_special_dash_input() -> void:
	if not special_dash_hold_active:
		return

	special_dash_hold_active = false

	# 地面已经立即启动普通 Dash。
	# 松开只结束长按输入，不额外启动 Dash。
	if special_dash_hold_started_on_floor:
		_reset_special_dash_hold_state()
		return

	# 空中松开：无论是短按还是特殊准备状态，
	# 当前版本都回退为一次普通 Dash。
	var direction: Vector2

	if special_dash_preparing:
		# 特殊准备状态使用最后有效方向。
		direction = _get_special_dash_direction()

	else:
		# 短按使用按下瞬间的方向。
		direction = special_dash_press_direction

		if direction == Vector2.ZERO:
			direction = Vector2(facing_direction, 0.0)

	dash_input_pending = true
	dash_input_direction = direction.normalized()
	dash_input_updates_facing = true

	special_dash_preparing = false

	_reset_special_dash_hold_state()


func _get_special_dash_direction() -> Vector2:
	# 特殊准备状态期间从未输入过有效方向：默认向上。
	if special_dash_last_valid_direction == Vector2.ZERO:
		return Vector2.UP

	return special_dash_last_valid_direction


func _try_ground_special_dash() -> void:
	pass
	# 当前暂不执行特殊动作。
	# 这里只保留一次性派生尝试的接口。
	# 后续在这里接入特殊 CombatAction。


func _reset_special_dash_hold_state() -> void:
	special_dash_hold_timer = 0.0
	special_dash_press_direction = Vector2.ZERO
	special_dash_last_valid_direction = Vector2.ZERO

	special_dash_hold_started_on_floor = false
	special_dash_ground_attempted = false


func _reset_special_dash_input_state() -> void:
	special_dash_hold_active = false
	special_dash_preparing = false
	dash_input_updates_facing = true

	_reset_special_dash_hold_state()


# ==================================================
# 物理更新
# ==================================================

func _physics_process(delta: float) -> void:
	if is_dead:
		velocity = Vector2.ZERO
		return

	if is_hitstop_paused:
		return

	var actor_delta: float = CombatTimeManager.get_actor_delta(
		self,
		delta
	)

	if actor_delta <= 0.0:
		return

	movement_controller.update_dash(actor_delta)

	movement_controller.update_coyote_time(
		actor_delta,
		is_on_floor()
	)

	movement_controller.update_jump_buffer(actor_delta)

	# Dash 期间由 MovementModule 接管速度；
	# 其他时候交给运动执行器。
	var velocity_override_active: bool = false
	var suppress_gravity: bool = false

	if not special_dash_preparing:
		var movement_result: Dictionary = movement_controller.update_action_movement(
			actor_delta,
			velocity,
			movement_controller.gravity,
			is_on_floor()
		)

		velocity_override_active = movement_result["active"]
		suppress_gravity = movement_result["suppress_gravity"]

		if velocity_override_active:
			velocity = movement_result["velocity"]

	# 速度阶段可以选择暂时抑制重力。
	velocity = movement_controller.apply_gravity(
		actor_delta,
		velocity,
		is_on_floor(),
		suppress_gravity
	)

	# 移动。
	if special_dash_preparing:
		# 特殊准备状态：
		# 不读取普通方向输入，保留当前水平动量。
		# 重力仍然正常生效。
		pass

	elif velocity_override_active:
		# 当前速度覆盖阶段已经接管速度，不执行普通移动。
		pass

	else:
		# 有方向输入时，立即更新角色面向。
		if move_input_direction != 0.0:
			_update_facing(move_input_direction)

		# 普通移动与蹲伏只在没有速度覆盖时执行。
		var is_crouching: bool = (
			is_on_floor()
			and Input.is_action_pressed("move_down")
		)

		velocity = movement_controller.update_movement(
			actor_delta,
			velocity,
			Vector2(move_input_direction, 0.0),
			is_on_floor(),
			is_crouching
		)

	# Dash 输入优先于普通跳跃。
	if dash_input_pending:
		dash_input_pending = false

		var dash_request_accepted: bool = request_dash(
			dash_input_direction,
			dash_input_updates_facing
		)

		dash_input_updates_facing = true

		# Dash 启动成功或第二段预输入成功时，不触发普通跳跃。
		if dash_request_accepted:
			jump_input_pending = false

	# 跳跃输入。
	if jump_input_pending:
		jump_input_pending = false

	if movement_controller.has_buffered_jump():
		if movement_controller.can_coyote_jump() and not is_dashing and not special_dash_preparing:
			velocity = movement_controller.apply_jump(velocity)

			# 如果跳跃真正启动时，跳跃键已经松开，
			# 立即执行一次跳跃截断。
			if not jump_button_held:
				velocity = movement_controller.cut_jump(velocity)

			movement_controller.coyote_timer = 0.0
			movement_controller.consume_buffered_jump()

	# 普通攻击输入。
	if normalattack_input_pending:
		normalattack_input_pending = false

		if not is_dashing:
			if combat_combo_executor.is_combo_running:
				if combat_combo_executor.current_combo_data == combat_combo_executor.combo_data:
					combat_combo_executor.request_next_action()
				else:
					combat_combo_executor.start_combo()
			else:
				combat_combo_executor.start_combo()

	# 技能输入。
	if skill_input_pending:
		skill_input_pending = false

		if not is_dashing:
			skill_selector.request_skill()
	# 动作稳定。
	if not is_dashing and not special_dash_preparing:
		velocity = movement_controller.apply_action_stabilization(
			velocity,
			actor_delta,
			is_on_floor()
		)


	move_and_slide()




# ==================================================
# 生命值与受击
# ==================================================

func take_damage(damage: float) -> void:
	if is_dead:
		return

	if damage <= 0.0:
		return

	current_health = maxf(current_health - damage, 0.0)

	if current_health <= 0.0:
		die()


func die() -> void:
	if is_dead:
		return

	is_dead = true

	velocity = Vector2.ZERO
	move_input_direction = 0.0
	move_input_vector = Vector2.ZERO

	jump_input_pending = false
	dash_input_pending = false
	normalattack_input_pending = false
	skill_input_pending = false

	dash_input_direction = Vector2.ZERO

	_reset_special_dash_input_state()

	if movement_controller != null:
		movement_controller.dash_buffered = false
		movement_controller.dash_buffered_direction = Vector2.ZERO


# ==================================================
# Hitstop 暂停接口
# ==================================================

func set_hitstop_paused(paused: bool) -> void:
	is_hitstop_paused = paused
	combat_action_executor.set_hitstop_paused(paused)


# ==================================================
# 角色面向
# ==================================================

func _update_facing(direction: float) -> void:
	facing_direction = sign(direction)
	$Polygon2D.scale.x = facing_direction


# ==================================================
# 请求 Dash
# ==================================================

func request_dash(
	direction: Vector2,
	update_facing: bool = true
) -> bool:
	return movement_controller.request_dash(
		direction,
		update_facing
	)


# ==================================================
# 统一调试接口
# ==================================================

func _set_debug_action(
	action_name: String,
	startup: float,
	active: float,
	recovery: float
) -> void:
	debug_action_name = action_name

	debug_startup_duration = startup
	debug_active_duration = active
	debug_recovery_duration = recovery

	debug_action_elapsed = 0.0
	debug_action_active = true

	if startup > 0.0:
		debug_phase_name = "前摇"
	else:
		debug_phase_name = "生效"


func _set_debug_phase(phase_name: String) -> void:
	debug_phase_name = phase_name


func _clear_debug_action() -> void:
	debug_action_name = "待机"
	debug_phase_name = ""

	debug_startup_duration = 0.0
	debug_active_duration = 0.0
	debug_recovery_duration = 0.0

	debug_action_elapsed = 0.0
	debug_action_active = false


# ==================================================
# Executor 调试信号
# ==================================================

func _on_executor_action_started(
	context: CombatActionContext
) -> void:
	var data := context.action_data

	_set_debug_action(
		data.action_name,
		data.startup,
		data.active,
		data.recovery
	)


func _on_executor_action_phase_changed(
	context: CombatActionContext
) -> void:
	match context.current_phase:
		&"startup":
			_set_debug_phase("前摇")

		&"active":
			_set_debug_phase("生效")

		&"recovery":
			_set_debug_phase("后摇")


func _on_executor_action_finished(
	context: CombatActionContext,
	was_cancelled: bool
) -> void:
	if combat_action_executor.current_context != context:
		return

	_clear_debug_action()


func _on_energy_changed(
	current_energy: float,
	max_energy: float
) -> void:
	debug_energy_current = current_energy
	debug_energy_max = max_energy
