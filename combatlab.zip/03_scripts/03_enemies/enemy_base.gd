
extends CharacterBody2D
class_name EnemyBase


@export_group("生命值")
@export var max_health: float = 100.0

@export_group("受击设置")
@export_range(0, 10, 1)
var default_super_armor_level: int = 0
@export var hit_reaction_action: CombatActionData


func get_effective_super_armor_level() -> int:
	if combat_action_executor.is_action_running():
		var action_data: CombatActionData = (
			combat_action_executor.current_context.action_data
		)

		if action_data.action_type == &"hit_reaction":
			return default_super_armor_level

		return action_data.super_armor_level

	return default_super_armor_level


var current_health: float = 0.0
var is_dead: bool = false

@onready var movement_controller: EnemyMovementController = $MovementController
@onready var combat_action_executor: CombatActionExecutor = $CombatActionExecutor
@onready var combat_combo_executor: CombatComboExecutor = $CombatComboExecutor
@onready var defense_controller: DefenseController = $DefenseController

@onready var polygon: Polygon2D = $Polygon2D
@onready var polygon_base_scale: Vector2 = $Polygon2D.scale
@onready var polygon_base_modulate: Color = $Polygon2D.modulate

@export_group("受击视觉效果")
@export_range(0.01, 0.2, 0.01)
var hit_flash_interval: float = 0.05

var hit_flash_timer: float = 0.0
var hit_flash_red: bool = false

var facing_direction: float = 1.0
var is_hitstop_paused: bool = false


func _ready() -> void:
	current_health = max_health

	if not HitManager.target_interrupted.is_connected(
		_on_target_interrupted
	):
		HitManager.target_interrupted.connect(
			_on_target_interrupted
	)


# ==============================
# 朝向
# ==============================

func get_facing_direction() -> int:
	return int(facing_direction)


func set_facing_direction(direction: float) -> void:
	if direction == 0.0:
		return

	facing_direction = signf(direction)

	polygon.scale.x = absf(polygon_base_scale.x) * facing_direction
	polygon.scale.y = polygon_base_scale.y


# ==============================
# 生命值与受伤
# ==============================

func take_damage(damage: float) -> void:
	if is_dead:
		return

	if damage <= 0.0:
		return

	current_health = maxf(current_health - damage, 0.0)

	print(name, "受到伤害：", damage)
	print("剩余生命值：", current_health)

	if current_health <= 0.0:
		die()


# ==============================
# 死亡
# ==============================

func die() -> void:
	if is_dead:
		return

	is_dead = true

	velocity = Vector2.ZERO
	movement_controller.stop_moving()

	if combat_combo_executor.is_combo_running:
		combat_combo_executor.cancel_combo()

	if combat_action_executor.is_action_running():
		combat_action_executor.cancel_action()

	print(name, "被击败！")


# ==============================
# Hitstop
# ==============================

func set_hitstop_paused(paused: bool) -> void:
	is_hitstop_paused = paused
	combat_action_executor.set_hitstop_paused(paused)

	if paused:
		hit_flash_timer = 0.0
		hit_flash_red = false
		polygon.modulate = polygon_base_modulate
	else:
		hit_flash_timer = 0.0
		hit_flash_red = false
		polygon.modulate = polygon_base_modulate


# ==============================
# 物理更新
# ==============================

func _physics_process(_delta: float) -> void:
	if is_dead or is_hitstop_paused:
		return

	movement_controller.update_movement()
	move_and_slide()

func _on_target_interrupted(
	target: Node,
	_attacker: Node,
	_action_progress: float,
	_phase_name: String
) -> void:
	if target != self:
		return

	if is_dead:
		return

	if hit_reaction_action == null:
		push_warning(name, "：没有配置受击 Action")
		return

	combat_action_executor.start_action(
		hit_reaction_action,
		self,
		get_facing_direction()
	)

func _process(delta: float) -> void:
	if not is_hitstop_paused:
		return

	hit_flash_timer += delta

	if hit_flash_timer >= hit_flash_interval:
		hit_flash_timer = 0.0
		hit_flash_red = not hit_flash_red

		if hit_flash_red:
			polygon.modulate = Color(1.0, 0.0, 0.0, 0.5)
		else:
			polygon.modulate = polygon_base_modulate