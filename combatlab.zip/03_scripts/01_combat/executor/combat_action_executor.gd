
extends Node
class_name CombatActionExecutor


# ==================================================
# 信号
# ==================================================

signal action_started(context: CombatActionContext)
signal action_phase_changed(context: CombatActionContext)
signal action_finished(context: CombatActionContext, was_cancelled: bool)


# ==================================================
# 当前动作
# ==================================================

var current_context: CombatActionContext = null

# 当前参与执行的模块。
var active_modules: Array[CombatActionModule] = []

# Hitstop 暂停标记。
var is_hitstop_paused: bool = false

# 保存最近一次 Movement Action 的调试数据。
var last_movement_debug: Dictionary = {}


# ==================================================
# 动作启动
# ==================================================

func start_action(
	action_data: CombatActionData,
	actor: Node2D,
	facing_direction: int = 1,
	input_direction: Vector2 = Vector2.ZERO
) -> bool:
	# 基础检查。
	if action_data == null:
		return false

	if actor == null:
		return false

	# 检查当前动作是否允许被覆盖。
	if is_action_running():
		if not _can_override_current_action(action_data):
			return false

	# 检查并消耗动作所需能量。
	# 必须在取消旧动作之前完成检查。
	if action_data.energy_cost > 0.0:
		var energy := actor.get_node_or_null("CombatEnergy") as CombatEnergy

		if energy == null:
			push_warning("CombatActionExecutor：动作需要能量，但角色没有 CombatEnergy")
			return false

		if not energy.consume_energy(action_data.energy_cost):
			print("能量不足，无法启动动作：", action_data.action_name)
			return false

	# 新动作成功通过启动检查，取消之前的成功闪避时缓。
	CombatTimeManager.cancel_successful_dodge_time_slow()

	# 如果旧动作仍在运行，标记为被新动作替换。
	if is_action_running():
		_finish_action(true, &"replaced")

	# 创建新动作上下文。
	current_context = CombatActionContext.new()
	current_context.setup(
		action_data,
		actor,
		facing_direction,
		input_direction
	)

	# 清理模块列表。
	active_modules.clear()
	current_context.module_debug_data.clear()

	# 收集并启动启用的模块。
	for module in action_data.modules:
		if module == null:
			continue

		if not module.module_enabled:
			continue

		active_modules.append(module)
		module.on_module_start(current_context)

		# 记录模块调试信息。
		current_context.module_debug_data.append({
			"module_id": String(module.get_module_id()),
			"module_name": module.module_name,
			"enabled": true,
			"running": true
		})

	action_started.emit(current_context)
	return true


# ==================================================
# 动作覆盖判断
# ==================================================

func _can_override_current_action(
	new_action: CombatActionData
) -> bool:
	if current_context == null:
		return true

	var current_action: CombatActionData = current_context.action_data

	# 当前动作禁止被覆盖。
	if current_action.unoverrideable:
		return false

	# 新动作优先级更高，可以无视普通取消阶段限制。
	if new_action.action_priority > current_action.action_priority:
		return true

	# 优先级相同或更低，检查当前动作是否允许在当前阶段被取消。
	var current_phase: StringName = current_context.current_phase
	if not current_action.can_be_cancelled_from(current_phase):
		return false

	return true


# ==================================================
# 动作更新
# ==================================================

func _process(delta: float) -> void:
	if is_hitstop_paused:
		return

	if not is_action_running():
		return

	var actor_delta: float = CombatTimeManager.get_actor_delta(
		current_context.actor,
		delta
	)

	# 锁定本次更新开始时的动作上下文。
	var processing_context: CombatActionContext = current_context
	var remaining_time: float = actor_delta

	# 防止异常配置导致阶段切换死循环。
	var safety_counter: int = 0

	while (
		processing_context.is_running
		and current_context == processing_context
		and safety_counter < 8
	):
		var phase_duration: float = _get_phase_duration()
		var phase_remaining: float = phase_duration - processing_context.phase_elapsed

		# 当前阶段已经结束，进入下一阶段。
		if phase_remaining <= 0.00001:
			_advance_phase()
			safety_counter += 1

			# 动作结束或被替换，立即退出旧动作循环。
			if (
				current_context != processing_context
				or not processing_context.is_running
			):
				return

			continue

		# 本次更新没有剩余时间。
		if remaining_time <= 0.0:
			break

		# 计算本次实际推进的时间。
		var step_time: float = min(remaining_time, phase_remaining)

		# 更新当前动作的所有模块。
		for module in active_modules:
			if (
				current_context != processing_context
				or not processing_context.is_running
			):
				return

			module.on_module_update(processing_context, step_time)

		# 再次确认动作没有被替换。
		if (
			current_context != processing_context
			or not processing_context.is_running
		):
			return

		# 更新动作计时。
		processing_context.phase_elapsed += step_time
		processing_context.elapsed_time += step_time
		remaining_time -= step_time
		safety_counter += 1


# ==================================================
# Hitstop 暂停接口
# ==================================================

func set_hitstop_paused(paused: bool) -> void:
	is_hitstop_paused = paused


# ==================================================
# 阶段时间
# ==================================================

func _get_phase_duration() -> float:
	if current_context == null:
		return 0.0

	var data: CombatActionData = current_context.action_data

	match current_context.current_phase:
		&"startup":
			return data.startup
		&"active":
			return data.active
		&"recovery":
			return data.recovery

	return 0.0


# ==================================================
# 阶段切换
# ==================================================

func _advance_phase() -> void:
	if current_context == null:
		return

	match current_context.current_phase:
		&"startup":
			current_context.set_phase(&"active")
			action_phase_changed.emit(current_context)

		&"active":
			current_context.set_phase(&"recovery")
			action_phase_changed.emit(current_context)

		&"recovery":
			_finish_action(false, &"completed")


# ==================================================
# 结束动作
# ==================================================

func _finish_action(
	was_cancelled: bool,
	end_reason: StringName
) -> void:
	if current_context == null:
		return

	# 防止同一个动作重复结束。
	if not current_context.is_running:
		return

	# 保存本次结束的动作上下文。
	var finished_context: CombatActionContext = current_context

	# 在模块清理运行数据之前，保存 Movement 调试信息。
	if finished_context.runtime_data.has("movement_debug"):
		last_movement_debug = finished_context.runtime_data["movement_debug"].duplicate(true)

	# 将结束原因写入 Context。
	# Module 可以在 on_module_end() 中读取。
	finished_context.runtime_data["action_end_reason"] = end_reason
	finished_context.runtime_data["action_was_cancelled"] = was_cancelled

	# 通知所有模块结束。
	for module in active_modules:
		module.on_module_end(finished_context)

	# 更新模块调试状态。
	for module_debug in finished_context.module_debug_data:
		module_debug["running"] = false

	finished_context.is_running = false
	action_finished.emit(finished_context, was_cancelled)


# ==================================================
# 主动取消动作
# ==================================================

func cancel_action() -> bool:
	if not is_action_running():
		return false

	_finish_action(true, &"cancelled")
	return true


# ==================================================
# 状态查询
# ==================================================

func is_action_running() -> bool:
	return (
		current_context != null
		and current_context.is_running
	)


# ==================================================
# Debug 数据接口
# ==================================================

func get_debug_data() -> Dictionary:
	# 当前没有动作上下文时，仍然提供上一次 Movement 调试数据。
	if current_context == null:
		var empty_runtime_data: Dictionary = {}

		if not last_movement_debug.is_empty():
			empty_runtime_data["movement_debug"] = last_movement_debug.duplicate(true)

		return {
			"action_active": false,
			"runtime_data": empty_runtime_data
		}

	# 复制当前运行数据，避免修改 Context 本身。
	var runtime_data: Dictionary = current_context.runtime_data.duplicate(true)

	# 当前动作没有 Movement 调试数据时，使用上一次保存的数据。
	if not runtime_data.has("movement_debug"):
		if not last_movement_debug.is_empty():
			runtime_data["movement_debug"] = last_movement_debug.duplicate(true)

	return {
		"action_active": current_context.is_running,
		"action_id": String(current_context.action_data.action_id),
		"action_name": current_context.action_data.action_name,
		"phase": String(current_context.current_phase),
		"elapsed_time": current_context.elapsed_time,
		"phase_elapsed": current_context.phase_elapsed,
		"facing_direction": current_context.facing_direction,
		"modules": current_context.module_debug_data,
		"runtime_data": runtime_data
	}
