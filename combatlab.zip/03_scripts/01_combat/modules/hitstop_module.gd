
@tool
extends CombatActionModule
class_name HitstopModule

const FRAME_DURATION: float = 1.0 / 60.0


# ==================================================
# 攻击者顿帧
# ==================================================

@export_group("攻击者顿帧")

@export var attacker_hitstop_enabled: bool = true


@export_range(0.0, 1.0, 0.001)
var attacker_hitstop_duration: float = 0.05:
	set(value):
		attacker_hitstop_duration = value
		target_hitstop_duration = value + FRAME_DURATION



# ==================================================
# 命中目标顿帧
# ==================================================

@export_group("命中目标顿帧")

@export var target_hitstop_enabled: bool = true

@export_range(0.0, 1.0, 0.001)
var target_hitstop_duration: float = 0.066667


# ==================================================
# 发出顿帧请求
# ==================================================


func apply_hitstop(context: CombatActionContext) -> void:
	if not is_instance_valid(context.actor):
		return

	if not HitManager.has_method("request_hitstop"):
		return

	if attacker_hitstop_enabled:
		HitManager.request_hitstop(
			context.actor,
			attacker_hitstop_duration
		)

	if target_hitstop_enabled:
		if is_instance_valid(context.target):
			HitManager.request_hitstop(
				context.target,
				target_hitstop_duration
			)
