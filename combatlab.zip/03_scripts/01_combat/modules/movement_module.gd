
@tool
extends CombatActionModule
class_name MovementModule


enum MovementMode {
	NONE,
	DASH,
	VELOCITY_OVERRIDE
}

enum DirectionSource {
	INPUT_DIRECTION,
	FACING_DIRECTION,
	CUSTOM_DIRECTION
}

enum EndVelocityMode {
	PRESERVE_CURRENT,
	SET_SPEED
}

enum OverridePhaseMode {
	SPEED_PROTECTION,
	LINEAR_INTERPOLATION,
	DIRECT_SET
}


# ==================================================
# Inspector 显示控制
# ==================================================

@export_group("额外位移")

@export var movement_mode: MovementMode = MovementMode.NONE:
	set(value):
		movement_mode = value
		notify_property_list_changed()


func _validate_property(property: Dictionary) -> void:
	var property_name: StringName = property.get("name", &"")

	var is_dash_mode: bool = movement_mode == MovementMode.DASH
	var is_override_mode: bool = movement_mode == MovementMode.VELOCITY_OVERRIDE

	var dash_properties: Array[StringName] = [
		&"dash_speed",
		&"dash_duration",
		&"dash_up_end_y_multiplier",
		&"dash_diagonal_up_end_y_multiplier",
		&"end_velocity_enabled",
		&"exclude_diagonal_down_end"
	]

	var override_properties: Array[StringName] = [
		&"override_phase_mode",
		&"override_duration",
		&"override_speed",
		&"override_direction_source",
		&"override_custom_direction",
		&"override_suppress_gravity",
		&"end_velocity_mode"
	]

	if property_name in dash_properties and not is_dash_mode:
		property.usage = PROPERTY_USAGE_NO_EDITOR

	if property_name in override_properties and not is_override_mode:
		property.usage = PROPERTY_USAGE_NO_EDITOR

	if property_name == &"end_speed":
		if not is_dash_mode and not is_override_mode:
			property.usage = PROPERTY_USAGE_NO_EDITOR


# ==================================================
# 动作稳定
# ==================================================

@export_group("动作稳定")

@export var stabilization_enabled: bool = true

@export_range(0.0, 10000.0, 50.0)
var stabilization_speed: float = 3000.0

@export var stabilize_vertical_in_air: bool = true


# ==================================================
# DASH 配置
# ==================================================

@export_group("DASH 配置")

@export_range(0.0, 3000.0, 10.0)
var dash_speed: float = 960.0

@export_range(0.01, 5.0, 0.01)
var dash_duration: float = 0.15

@export_range(0.0, 1.0, 0.01)
var dash_up_end_y_multiplier: float = 0.75

@export_range(0.0, 1.0, 0.01)
var dash_diagonal_up_end_y_multiplier: float = 0.75

@export var end_velocity_enabled: bool = true

@export var exclude_diagonal_down_end: bool = true


# ==================================================
# 通用速度覆盖配置
# ==================================================

@export_group("通用速度覆盖")

@export var override_phase_mode: OverridePhaseMode = OverridePhaseMode.SPEED_PROTECTION

@export_range(0.01, 5.0, 0.01)
var override_duration: float = 0.15

@export_range(0.0, 3000.0, 10.0)
var override_speed: float = 240.0

@export var override_direction_source: DirectionSource = DirectionSource.INPUT_DIRECTION

@export var override_custom_direction: Vector2 = Vector2.RIGHT

@export var override_suppress_gravity: bool = false


# ==================================================
# 结束速度设置
# ==================================================

@export_group("结束速度设置")

@export var end_velocity_mode: EndVelocityMode = EndVelocityMode.PRESERVE_CURRENT

@export_range(0.0, 3000.0, 10.0)
var end_speed: float = 160.0


# ==================================================
# 模块接口
# ==================================================

func get_module_id() -> StringName:
	return &"movement"


func on_module_start(context: RefCounted) -> void:
	var action_context := context as CombatActionContext

	if action_context == null:
		return

	if not is_instance_valid(action_context.actor):
		return

	var movement_request := {
		"movement_mode": movement_mode,

		"stabilization_enabled": stabilization_enabled,
		"stabilization_speed": stabilization_speed,
		"stabilize_vertical_in_air": stabilize_vertical_in_air,

		"end_velocity_mode": end_velocity_mode,
		"end_speed": end_speed
	}

	var movement_debug := {
		"movement_mode": _get_movement_mode_name(),

		"stabilization_enabled": stabilization_enabled,

		# 暂时保留旧字段名称，兼容现有 Debug 界面。
		"velocity_override_enabled": movement_mode != MovementMode.NONE,
		"velocity_override_active": false,
		"velocity_override_finished": false,

		"velocity_phase_index": 0,
		"velocity_phase_count": 1 if movement_mode != MovementMode.NONE else 0,
		"velocity_phase_elapsed": 0.0,

		"suppress_gravity": false
	}

	if movement_mode == MovementMode.DASH:
		var direction := action_context.input_direction

		if direction.length_squared() <= 0.0001:
			direction = Vector2.RIGHT * action_context.facing_direction

		direction = direction.normalized()

		movement_request.merge({
			"dash_speed": dash_speed,
			"dash_duration": dash_duration,
			"dash_direction": direction,
			"end_velocity_enabled": end_velocity_enabled,
			"exclude_diagonal_down_end": exclude_diagonal_down_end,
			"dash_up_end_y_multiplier": dash_up_end_y_multiplier,
			"dash_diagonal_up_end_y_multiplier": dash_diagonal_up_end_y_multiplier
		})

		movement_debug.merge({
			"dash_speed": dash_speed,
			"dash_duration": dash_duration,
			"dash_direction": direction
		})

	elif movement_mode == MovementMode.VELOCITY_OVERRIDE:
		var direction := _get_direction(
			action_context,
			override_direction_source,
			override_custom_direction
		)

		movement_request.merge({
			"override_phase_mode": override_phase_mode,
			"override_duration": override_duration,
			"override_speed": override_speed,
			"override_direction": direction,
			"override_suppress_gravity": override_suppress_gravity
		})

		movement_debug.merge({
			"override_phase_mode": override_phase_mode,
			"override_duration": override_duration,
			"override_speed": override_speed,
			"override_direction": direction
		})

	# 为当前 Action 和当前 Module 生成唯一来源 ID。
	var movement_source_id := StringName(
		"action_%d_module_%d" % [
			action_context.get_instance_id(),
			get_instance_id()
		]
	)

	movement_debug["movement_source_id"] = movement_source_id

	# NONE 只保留原有配置和 Debug 数据，不申请运动控制权。
	if movement_mode != MovementMode.NONE:
		var movement_controller := action_context.actor.get(
			"movement_controller"
		) as PlayerMovementController

		if movement_controller == null:
			push_warning(
				"MovementModule: 无法获取 PlayerMovementController，Movement 请求未提交。"
			)
		else:
			var accepted := movement_controller.receive_action_movement_request(
				movement_source_id,
				movement_request
			)

			if accepted:
				action_context.runtime_data["movement_source_id"] = movement_source_id
			else:
				push_warning(
					"MovementModule: PlayerMovementController 拒绝了 Movement 请求。"
				)

	# 保留 Context 中的请求和 Debug 数据。
	# Controller 接收的是自己的独立副本。
	action_context.runtime_data["movement_request"] = movement_request
	action_context.runtime_data["movement_debug"] = movement_debug


func on_module_end(context: RefCounted) -> void:
	var action_context := context as CombatActionContext

	if action_context == null:
		return

	# 只有成功提交过 Movement 请求的模块才需要通知 Controller。
	var movement_source_id: StringName = StringName(
		action_context.runtime_data.get("movement_source_id", &"")
	)

	if movement_source_id != &"":
		var movement_controller := action_context.actor.get(
			"movement_controller"
		) as PlayerMovementController

		if movement_controller != null:
			var action_end_reason: StringName = StringName(
				action_context.runtime_data.get(
					"action_end_reason",
					&"cancelled"
				)
			)

			var movement_end_reason: PlayerMovementController.MovementEndReason

			match action_end_reason:
				&"completed":
					movement_end_reason = PlayerMovementController.MovementEndReason.COMPLETED

				&"replaced":
					movement_end_reason = PlayerMovementController.MovementEndReason.REPLACED

				&"cancelled":
					movement_end_reason = PlayerMovementController.MovementEndReason.CANCELLED

				_:
					push_warning(
						"MovementModule: 未知的 Action 结束原因：%s，按取消处理。"
						% action_end_reason
					)
					movement_end_reason = PlayerMovementController.MovementEndReason.CANCELLED

			movement_controller.notify_movement_action_finished(
				movement_source_id,
				movement_end_reason
			)

	# 最后才清理旧 Context 的数据。
	action_context.runtime_data.erase("movement_request")
	action_context.runtime_data.erase("movement_debug")
	action_context.runtime_data.erase("movement_source_id")

# ==================================================
# Debug 数据
# ==================================================

func _get_movement_mode_name() -> String:
	match movement_mode:
		MovementMode.DASH:
			return "DASH"

		MovementMode.VELOCITY_OVERRIDE:
			return "VELOCITY_OVERRIDE"

		_:
			return "NONE"


# ==================================================
# 方向计算
# ==================================================

func _get_direction(
	context: CombatActionContext,
	source: DirectionSource,
	custom_direction: Vector2
) -> Vector2:

	var direction := Vector2.ZERO

	match source:
		DirectionSource.INPUT_DIRECTION:
			direction = context.input_direction

		DirectionSource.FACING_DIRECTION:
			direction = Vector2.RIGHT * context.facing_direction

		DirectionSource.CUSTOM_DIRECTION:
			direction = custom_direction

	if direction.length_squared() <= 0.0001:
		direction = Vector2.RIGHT * context.facing_direction

	return direction.normalized()
