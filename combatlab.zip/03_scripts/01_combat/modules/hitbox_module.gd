
@tool
extends CombatActionModule
class_name HitboxModule


@export_group("攻击判定")

@export var damage: float = 10.0

@export var hitbox_size: Vector2 = Vector2(80.0, 50.0)

# 以 Player 根节点原点为基准的局部坐标
@export var hitbox_offset: Vector2 = Vector2(45.0, 0.0)


func get_module_id() -> StringName:
	return &"hitbox"


# ==================================================
# 模块启动
# ==================================================

func on_module_start(context: RefCounted) -> void:
	var attack_area := _get_attack_area(context)

	if attack_area == null:
		push_warning("HitboxModule：找不到 AttackArea")
		return

	var collision_shape := attack_area.get_node_or_null("CollisionShape2D") as CollisionShape2D

	if collision_shape == null:
		push_warning("HitboxModule：找不到 CollisionShape2D")
		return

	if collision_shape.shape == null:
		push_warning("HitboxModule：CollisionShape2D 没有 Shape")
		return

	# 复制 Shape，避免修改共享资源
	collision_shape.shape = collision_shape.shape.duplicate()

	var rectangle := collision_shape.shape as RectangleShape2D

	if rectangle == null:
		push_warning("HitboxModule：当前只支持矩形判定")
		return

	# 设置判定尺寸
	rectangle.size = hitbox_size

	# 碰撞形状中心归零
	collision_shape.position = Vector2.ZERO

	# 设置 Hitbox 位置
	_update_hitbox_position(context, attack_area)

	# 初始化命中记录
	var hit_targets: Array[Node2D] = []
	context.runtime_data["hitbox_hit_targets"] = hit_targets

	# 初始化调试数据
	context.runtime_data["hitbox_damage"] = damage
	context.runtime_data["hitbox_size"] = hitbox_size
	context.runtime_data["hitbox_offset"] = hitbox_offset
	context.runtime_data["hitbox_enabled"] = false

	# 关闭判定
	attack_area.set_deferred("monitoring", false)

	# 连接命中信号
	var callback := Callable(self, "_on_body_entered").bind(context)

	if not attack_area.body_entered.is_connected(callback):
		attack_area.body_entered.connect(callback)

	context.runtime_data["hitbox_callback"] = callback

	print("HitboxModule：判定模块启动，伤害值：", damage)


# ==================================================
# 模块更新
# ==================================================

func on_module_update(context: RefCounted, _delta: float) -> void:
	var attack_area := _get_attack_area(context)

	if attack_area == null:
		return

	# 根据当前朝向更新位置
	_update_hitbox_position(context, attack_area)

	# 只有 Active 阶段开启判定
	var should_enable: bool = context.current_phase == &"active"

	if attack_area.monitoring != should_enable:
		attack_area.set_deferred("monitoring", should_enable)

	context.runtime_data["hitbox_enabled"] = should_enable


# ==================================================
# 模块结束
# ==================================================

func on_module_end(context: RefCounted) -> void:
	var attack_area := _get_attack_area(context)

	if attack_area != null:
		attack_area.set_deferred("monitoring", false)

		# 断开本次动作的命中信号
		var callback: Callable = context.runtime_data.get(
			"hitbox_callback",
			Callable()
		)

		if callback.is_valid() and attack_area.body_entered.is_connected(callback):
			attack_area.body_entered.disconnect(callback)

	context.runtime_data["hitbox_enabled"] = false

	print("HitboxModule：判定模块结束")


# ==================================================
# 命中处理
# ==================================================

func _on_body_entered(body: Node2D, context: RefCounted) -> void:
	if not context.is_running:
		return

	if context.current_phase != &"active":
		return

	if body == context.actor:
		return

	# 忽略已经死亡的目标
	if body.get("is_dead") == true:
		return

	if not body.has_method("take_damage"):
		return

	# 获取受击方的防御管理器
	var target_defense := body.get_node_or_null(
		"DefenseController"
	) as DefenseController

	if target_defense == null:
		push_warning("HitboxModule：目标缺少 DefenseController")
		return

	# 判断受击结果
	var hit_result: int = target_defense.get_hit_result()

	# 无敌：攻击无效，不记录命中，也不触发普通顿帧
	if hit_result == DefenseController.HitResult.INVINCIBLE:
		# 只有当前无敌来源允许成功闪避反馈时才触发时缓
		if target_defense.should_trigger_time_slow_on_success():
			CombatTimeManager.trigger_successful_dodge_time_slow()
			print("HitboxModule：成功闪避，触发全局时缓")
		else:
			print("HitboxModule：目标处于无敌状态，攻击无效")

		return

	# 正常命中和免伤都记录目标，防止重复触发
	var hit_targets: Array = context.runtime_data.get(
		"hitbox_hit_targets",
		[]
	)

	if body in hit_targets:
		return

	hit_targets.append(body)
	context.target = body

	# 正常命中：扣除生命值
	if hit_result == DefenseController.HitResult.HIT:
		body.take_damage(damage)

		# 造成伤害后，检查能否打断目标
		HitManager.process_hit(context as CombatActionContext, body)

		# 只有真正造成伤害时才显示伤害数字
		if context.actor != null and context.actor.has_signal("debug_damage_number"):
			context.actor.emit_signal(
				"debug_damage_number",
				body.global_position,
				damage
			)

		print("HitboxModule：正常命中 ", body.name, " | 伤害：", damage)

	# 免伤：不扣血，但仍然算有效命中
	elif hit_result == DefenseController.HitResult.IMMUNE:
		print("HitboxModule：目标处于免伤状态，未造成伤害")

	# 正常命中和免伤都会触发双方 Hitstop
	_apply_hitstop(context)


# ==================================================
# 触发顿帧
# ==================================================

func _apply_hitstop(context: RefCounted) -> void:
	if context.action_data == null:
		return

	for module in context.action_data.modules:
		if module is HitstopModule:
			module.apply_hitstop(context)
			return


# ==================================================
# 坐标控制
# ==================================================

func _update_hitbox_position(
	context: RefCounted,
	attack_area: Area2D
) -> void:
	var direction: int = context.facing_direction

	attack_area.position = Vector2(
		hitbox_offset.x * direction,
		hitbox_offset.y
	)


# ==================================================
# 获取攻击判定节点
# ==================================================

func _get_attack_area(context: RefCounted) -> Area2D:
	if context.actor == null:
		return null

	return context.actor.get_node_or_null("AttackArea") as Area2D
